import { CatalogProduct } from '@/types/catalog';
import Link from 'next/link';

type ProductCardProps = {
  product: CatalogProduct;
  onAdd: () => void;
};

export function ProductCard({ product, onAdd }: ProductCardProps) {
  const image = product.images.find((i) => i.isPrimary) ?? product.images[0];

  return (
    <article className="rounded-xl border overflow-hidden bg-black">
      <div className="aspect-square overflow-hidden bg-neutral-900">
        {image ? (
          <img
            src={image.url}
            alt={image.alt ?? product.name}
            className="w-full aspect-square object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="text-neutral-600 text-xs">Sin imagen</span>
          </div>
        )}
      </div>

      <div className="p-3">
        <p className="text-xs text-neutral-500 mb-1">
          {product.brand.name}
        </p>
        <h3 className="font-medium text-sm leading-tight">{product.name}</h3>
        <p className="mt-2 font-bold">
          ${Number(product.price).toLocaleString('es-AR')}
        </p>

        <Link
          href={`/producto/${product.slug}`}
          className="mt-3 block rounded-lg border py-2 text-center text-sm"
        >
          Ver producto
        </Link>

        <button
          onClick={onAdd}
          className="mt-2 w-full rounded-lg bg-green-600 py-2 text-sm font-semibold"
        >
          Agregar a consulta
        </button>
      </div>
    </article>
  );
}