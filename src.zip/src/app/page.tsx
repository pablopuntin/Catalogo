'use client';

import { useEffect, useState } from 'react';
import { Header } from '@/components/layout/Header';
import { SearchBar } from '@/components/catalog/SearchBar';
import { CategoryList } from '@/components/catalog/CategoryList';
import { ProductGrid } from '@/components/catalog/ProductGrid';
import { catalogService } from '@/services/catalog.service';
import { CatalogProduct, CatalogCategory } from '@/types/catalog';

type CartItem = {
  product: CatalogProduct;
  quantity: number;
};

export default function Home() {
  const [products, setProducts] = useState<CatalogProduct[]>([]);
  const [categories, setCategories] = useState<CatalogCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [search, setSearch] = useState('');

  useEffect(() => {
    Promise.all([
      catalogService.getProducts(),
      catalogService.getCategories(),
    ])
      .then(([prods, cats]) => {
        setProducts(prods);
        setCategories(cats);
      })
      .finally(() => setLoading(false));
  }, []);

  function handleAdd(product: CatalogProduct) {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity < 5 ? item.quantity + 1 : 5 }
            : item,
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  }

  const filteredProducts = products.filter((product) => {
    const matchCategory =
      selectedCategory === 'Todos'
        ? true
        : product.categories.some(
            (c) => c.category.name === selectedCategory,
          );

    const matchSearch = product.name
      .toLowerCase()
      .includes(search.toLowerCase());

    return matchCategory && matchSearch;
  });

  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const whatsappMessage =
    cart.length === 0
      ? 'Hola, quisiera realizar una consulta.'
      : `Hola, quisiera consultar por los siguientes productos:\n\n${cart
          .map(
            (item) =>
              `🛍️ ${item.product.name} x${item.quantity} - $${Number(item.product.price).toLocaleString('es-AR')}`,
          )
          .join('\n')}\n\n¿Tenés disponibilidad?\n\nTotal de productos: ${totalItems}`;

  function handleWhatsApp() {
    const phone = '5493857408499';
    window.open(
      `https://wa.me/${phone}?text=${encodeURIComponent(whatsappMessage)}`,
      '_blank',
    );
  }

  return (
    <>
      <Header count={totalItems} message={whatsappMessage} />

      <main className="p-4">
        <SearchBar search={search} onSearchChange={setSearch} />

        <CategoryList
          categories={[
            { id: 'all', name: 'Todos', slug: 'todos' },
            ...categories,
          ]}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />

        {loading ? (
          <p className="text-center text-neutral-400 text-sm py-16">
            Cargando productos...
          </p>
        ) : (
          <ProductGrid products={filteredProducts} onAdd={handleAdd} />
        )}
      </main>

      <button
        onClick={handleWhatsApp}
        className="fixed bottom-4 right-4 bg-green-600 text-white px-4 py-3 rounded-full shadow-lg text-sm font-semibold"
      >
        WhatsApp ({totalItems})
      </button>
    </>
  );
}